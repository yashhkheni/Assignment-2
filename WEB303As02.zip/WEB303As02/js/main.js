// WEB303 Assignment 2


$(document).ready(function() {
  const prospect = $('#prospect');
  const convert = $('#convert');
  const retain = $('#retain');

  const content = $('#content');

  const buttons = [prospect, convert, retain];

 buttons.forEach(button => {
    button.on("click", function(e) {
      const fileName = `${e.target.id}.html`;
      content.slideUp(500, function() {
        $.ajax({
          url: fileName,
          success: function(data) {
            content.html(data);
            content.slideDown();
         }
        });
      });
    });
  });
});


